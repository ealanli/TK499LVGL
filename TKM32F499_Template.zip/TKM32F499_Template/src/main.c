#include "HAL_conf.h"
#include "sys.h"

#define LED_GPIO		GPIOB
#define LED_Pin			GPIO_Pin_13

int main(void) {
	GPIO_InitTypeDef GPIO_InitStructure; //定义GPIO初始化结构体变量
	//	AI_Responder_enable();// 仿真时请注释掉，抢答器具有乱序发射特性；如果在bootloader中已打开，非仿真方式运行开不开都没所谓，注释掉照样在运行。
	RemapVtorTable();
	SystemClk_HSEInit(RCC_PLLMul_20);	//启动PLL时钟，12MHz*20=240MHz
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);

	//配置连接LED的GPIO为推挽输出模式
	GPIO_InitStructure.GPIO_Pin = LED_Pin;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(LED_GPIO, &GPIO_InitStructure);

	while (1)	//无限循环
	{
		GPIO_SetBits(LED_GPIO, LED_Pin); // 点亮LED
		for (u32 i = 0; i < 10000000; i++)
			; //延时

		GPIO_ResetBits(LED_GPIO, LED_Pin); // 熄灭LED
		for (u32 i = 0; i < 10000000; i++)
			; //延时
	}

}
