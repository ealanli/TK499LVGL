# !/bin/bash

BIN="/disks/LinuxData/Projects/Eclipse_EmbedCPP/TKM32F499_LVGL7/Debug/TKM32F499_LVGL7.bin"
OUTDIR="/run/media/legion/TK499_V2/"

echo "正在复制固件到单片机..."
cp ${BIN} ${OUTDIR}

echo "复制完毕会自动弹出单片机"
