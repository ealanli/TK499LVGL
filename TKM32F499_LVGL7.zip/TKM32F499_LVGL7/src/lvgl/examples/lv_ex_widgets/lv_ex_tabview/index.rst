C
^

Simple Tabview 
"""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_tabview/lv_ex_tabview_1
  :language: c


MicroPython
^^^^^^^^^^^

Simple Tabview 
"""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_tabview/lv_ex_tabview_1
  :language: py

