#include "touch.h"
#include "HAL_rcc.h"
#include "Hardware/lcd/lcd.h"

static u16 touchX = 0;
static u16 touchY = 0;

void Touch_Init() {
	I2C_InitMasterMode(I2C1);
}

int Touch_IsPressed() {
	u8 buf[32];
	I2C_TXByte(I2C1, CMD_WRITE, 0x01);

	*(buf) = I2C_RXByte(I2C1); //库函数法读取IIC数据
	*(buf + 1) = I2C_RXByte(I2C1); //库函数法读取IIC数据
	if ((buf[1] & 0x0f) == 1) {
		for (u8 i = 2; i < 6; i++) {
			*(buf + i) = I2C_RXByte(I2C1); //库函数法读取IIC数据
		}

		touchX = (buf[2] & 0x0F) << 8 | buf[3]; //x坐标
		touchY = (buf[4] & 0x0F) << 8 | buf[5]; //y坐标

		return 1;
	}
	return 0;
}

void Touch_GetPos(u16 *x, u16 *y) {
	*x = touchX;
	*y = touchY;
}
