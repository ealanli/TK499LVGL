/*
 * lcd.c
 *
 *  Created on: 2022年8月10日
 *      Author: legion
 */
#include "lcd.h"

__attribute__ ((aligned(256))) u32 LTDC_Buf[XSIZE_PHYS * YSIZE_PHYS];

static void LCD_SPI_CS(u8 state) {
	if (state)
		GPIOE->BSRR = GPIO_Pin_9;
	else
		GPIOE->BRR = GPIO_Pin_9;
}

static void LCD_SPI_DCLK(u8 state) {
	if (state)
		GPIO_SetBits(GPIOE, GPIO_Pin_23);
	else
		GPIO_ResetBits(GPIOE, GPIO_Pin_23);
}

static void LCD_SPI_SDA(u8 state) {
	if (state)
		GPIO_SetBits(GPIOE, GPIO_Pin_22);
	else
		GPIO_ResetBits(GPIOE, GPIO_Pin_22);
}

static void LCD_RST(u8 state) {
	if (state)
		GPIO_SetBits(GPIOE, GPIO_Pin_17);
	else
		GPIO_ResetBits(GPIOE, GPIO_Pin_17);
}

static void LCD_Light_ON() {
	GPIO_SetBits(GPIOE, GPIO_Pin_16);
}

static void LCD_Light_OFF() {
	GPIO_ResetBits(GPIOE, GPIO_Pin_16);
}

static void LCD_delay(volatile int time)  //简单软件延时
{
	volatile u32 i;
	while (time--)
		for (i = 500; i > 0; i--)
			;
}
static void LCD_SPI_WriteByte(unsigned char byte) {
	unsigned char n;

	for (n = 0; n < 8; n++) {
		if (byte & 0x80)
			LCD_SPI_SDA(1);
		else
			LCD_SPI_SDA(0);
		byte <<= 1;
		LCD_SPI_DCLK(0);
		LCD_SPI_DCLK(1);
	}
}

static void LCD_SPI_WriteComm(u16 CMD) //3线8bit 串行接口
{
	LCD_SPI_CS(0);
	LCD_SPI_WriteByte(0x70);
	LCD_SPI_WriteByte(CMD);
	LCD_SPI_CS(1);
}

static void LCD_SPI_WriteData(u16 tem_data) {
	LCD_SPI_CS(0);
	LCD_SPI_WriteByte(0x72);
	LCD_SPI_WriteByte(tem_data);
	LCD_SPI_CS(1);
}

static void LCD_SetClockOfLTDC()	//设置LTDC时钟
{
	RCC->AHB1ENR |= 1 << 31;
	RCC->CR |= 1 << 28;
	RCC->PLLDCKCFGR = 0x1 << 16;  //分频系数 0~3 --> 2,4,6,8
	RCC->PLLLCDCFGR = 6 << 6;   	//倍频系数
}
static void LCD_SetResolutionXX(LCD_FORM_TypeDef *LCD_FORM) {
	u32 aHorStart;
	u32 aHorEnd;
	u32 aVerStart;
	u32 aVerEnd;

	aHorStart = LCD_FORM->blkHorEnd + 1;
	aHorEnd = aHorStart + LCD_FORM->aHorLen;
	aVerStart = LCD_FORM->blkVerEnd + 1;
	aVerEnd = aVerStart + LCD_FORM->aVerLen;

	LTDC->P_HOR = aHorEnd; //总宽度
	LTDC->HSYNC = (LCD_FORM->sHsyncStart << 16) | LCD_FORM->sHsyncEnd; //水平同步信号起始和结束，位于背景色中间
	LTDC->A_HOR = (aHorStart << 16) | aHorEnd; //水平激活起始和结束
	LTDC->A_HOR_LEN = LCD_FORM->aHorLen; //水平激活域宽度
	LTDC->BLK_HOR = (0 << 16) | LCD_FORM->blkHorEnd; //背景开始和结束宽度0~激活地址
	LTDC->P_VER = aVerEnd;
	LTDC->VSYNC = (LCD_FORM->sVsyncStart << 16) | LCD_FORM->sVsyncEnd;
	LTDC->A_VER = (aVerStart << 16) | aVerEnd;
	LTDC->A_VER_LEN = LCD_FORM->aVerLen;
	LTDC->BLK_VER = (0 << 16) | LCD_FORM->blkVerEnd;
}

static void LCD_SetTimingToLTDC() {
	LCD_FORM_TypeDef LCD_FORM;
	LTDC->OUT_EN = 0;
	LTDC->DP_ADDR0 = (u32) LTDC_Buf; //第0层地址
//    LTDC->DP_ADDR1 = (u32)(LTDC_Buf + SDRAM_RGB_OFFSET);//第一层地址
	LTDC->BLK_DATA = 0x0000; //背景色

	LCD_FORM.sHsyncStart = 0x2;  //水平激活起始
	LCD_FORM.sHsyncEnd = 0x3;    //水平激活结束
	LCD_FORM.aHorLen = 480 - 1;  //水平分辨率
	LCD_FORM.blkHorEnd = 0x15;    //水平消隐

	LCD_FORM.sVsyncStart = 0x2;  //垂直激活起始
	LCD_FORM.sVsyncEnd = 0x8;    //垂直激活结束
	LCD_FORM.aVerLen = 800 - 1; 	 //垂直分辨率
	LCD_FORM.blkVerEnd = 0xf;   //垂直消隐

	LCD_SetResolutionXX(&LCD_FORM);

	LTDC->VI_FORMAT = 0;
	LTDC->POL_CTL = 0x2 + 8;
	LTDC->OUT_EN |= 0x107;
}

static void LCD_Reset() {
	//注意，现在科学发达，有的屏不用复位也行
	LCD_RST(0);
	LCD_delay(200);
	LCD_RST(1);
	LCD_delay(200);

}

static void LCD_Initialize() {
	LCD_SPI_CS(1);
	LCD_delay(20);
	LCD_SPI_CS(0);
	LCD_Reset();

	LCD_SPI_WriteComm(0x20); //exit_invert_mode
	LCD_SPI_WriteComm(0x29); //set_display_on

	LCD_SPI_WriteComm(0xB1); //RGB Interface Setting
	LCD_SPI_WriteData(0x00);
	LCD_SPI_WriteData(0x14);
	LCD_SPI_WriteData(0x06);

	LCD_SPI_WriteComm(0xB2); //Panel Characteristics Setting
	LCD_SPI_WriteData(0x10); //480 pixels
	LCD_SPI_WriteData(0xC8); //800 pixels

	LCD_SPI_WriteComm(0xB3); //Panel Drive Setting    Set the inversion mode

	LCD_SPI_WriteData(0x00); //1-dot inversion 0x01

	LCD_SPI_WriteComm(0xB4); //Display Mode Control
	LCD_SPI_WriteData(0x04); //Dither disable.

	LCD_SPI_WriteComm(0xB5); //Display Mode and Frame Memory Write Mode Setting
	LCD_SPI_WriteData(0x10);
	LCD_SPI_WriteData(0x30);
	LCD_SPI_WriteData(0x30);
	LCD_SPI_WriteData(0x00);
	LCD_SPI_WriteData(0x00);

	LCD_SPI_WriteComm(0xB6); //Display Control 2 ( GIP Specific )
	LCD_SPI_WriteData(0x01);
	LCD_SPI_WriteData(0x18);
	LCD_SPI_WriteData(0x02);
	LCD_SPI_WriteData(0x40);
	LCD_SPI_WriteData(0x10);
	LCD_SPI_WriteData(0x00);

	LCD_SPI_WriteComm(0xc0);
	LCD_SPI_WriteData(0x01);
	LCD_SPI_WriteData(0x18);

	LCD_SPI_WriteComm(0xC3);
	LCD_SPI_WriteData(0x03);
	LCD_SPI_WriteData(0x04);
	LCD_SPI_WriteData(0x03);
	LCD_SPI_WriteData(0x03);
	LCD_SPI_WriteData(0x03);

	LCD_delay(10);

	LCD_SPI_WriteComm(0xC4); //VDD Regulator setting
	LCD_SPI_WriteData(0x02);
	LCD_SPI_WriteData(0x23); //GDC AP
	LCD_SPI_WriteData(0x11); //VRH1  Vreg1out=1.533xVCI(10)
	LCD_SPI_WriteData(0x12); //VRH2  Vreg2out=-1.533xVCI(10)
	LCD_SPI_WriteData(0x02); //BT 5 VGH/VGL  6/-4
	LCD_SPI_WriteData(0x77); //DDVDH 6C//0x56
	LCD_delay(10);

	LCD_SPI_WriteComm(0xC5);
	LCD_SPI_WriteData(0x73);
	LCD_delay(10);

	LCD_SPI_WriteComm(0xC6);
	LCD_SPI_WriteData(0x24); //VCI 23
	LCD_SPI_WriteData(0x60); //RESET RCO 53
	LCD_SPI_WriteData(0x00); //SBC GBC
	LCD_delay(10);
	//GAMMA SETTING
	LCD_SPI_WriteComm(0xD0);
	LCD_SPI_WriteData(0x14);
	LCD_SPI_WriteData(0x01);
	LCD_SPI_WriteData(0x53);
	LCD_SPI_WriteData(0x25);
	LCD_SPI_WriteData(0x02);
	LCD_SPI_WriteData(0x02);
	LCD_SPI_WriteData(0x66);
	LCD_SPI_WriteData(0x14);
	LCD_SPI_WriteData(0x03);

	LCD_SPI_WriteComm(0xD1);
	LCD_SPI_WriteData(0x14);
	LCD_SPI_WriteData(0x01);
	LCD_SPI_WriteData(0x53);
	LCD_SPI_WriteData(0x07);
	LCD_SPI_WriteData(0x02);
	LCD_SPI_WriteData(0x02);
	LCD_SPI_WriteData(0x66);
	LCD_SPI_WriteData(0x14);
	LCD_SPI_WriteData(0x03);

	LCD_SPI_WriteComm(0xD2);
	LCD_SPI_WriteData(0x14);
	LCD_SPI_WriteData(0x01);
	LCD_SPI_WriteData(0x53);
	LCD_SPI_WriteData(0x25);
	LCD_SPI_WriteData(0x02);
	LCD_SPI_WriteData(0x02);
	LCD_SPI_WriteData(0x66);
	LCD_SPI_WriteData(0x14);
	LCD_SPI_WriteData(0x03);

	LCD_SPI_WriteComm(0xD3);
	LCD_SPI_WriteData(0x14);
	LCD_SPI_WriteData(0x01);
	LCD_SPI_WriteData(0x53);
	LCD_SPI_WriteData(0x07);
	LCD_SPI_WriteData(0x02);
	LCD_SPI_WriteData(0x02);
	LCD_SPI_WriteData(0x66);
	LCD_SPI_WriteData(0x14);
	LCD_SPI_WriteData(0x03);

	LCD_SPI_WriteComm(0xD4);
	LCD_SPI_WriteData(0x14);
	LCD_SPI_WriteData(0x01);
	LCD_SPI_WriteData(0x53);
	LCD_SPI_WriteData(0x25);
	LCD_SPI_WriteData(0x02);
	LCD_SPI_WriteData(0x02);
	LCD_SPI_WriteData(0x66);
	LCD_SPI_WriteData(0x14);
	LCD_SPI_WriteData(0x03);

	LCD_SPI_WriteComm(0xD5);
	LCD_SPI_WriteData(0x14);
	LCD_SPI_WriteData(0x01);
	LCD_SPI_WriteData(0x53);
	LCD_SPI_WriteData(0x07);
	LCD_SPI_WriteData(0x02);
	LCD_SPI_WriteData(0x02);
	LCD_SPI_WriteData(0x66);
	LCD_SPI_WriteData(0x14);
	LCD_SPI_WriteData(0x03);
	LCD_SPI_WriteComm(0x11);

	LCD_delay(10);

	LCD_SPI_WriteComm(0x3A);
	LCD_SPI_WriteData(0x66); //set_pixel_format 0X60 26k
	LCD_SPI_WriteComm(0x36);
	LCD_SPI_WriteData(0x2A);
	LCD_SPI_WriteComm(0x29);
	LCD_SPI_WriteComm(0x2c);
}
static void LCD_GpioInit() {

	GPIO_InitTypeDef GPIO_InitStructure;   	//定义GPIO初始化结构体变量

	RCC_AHBPeriphClockCmd(
	RCC_AHBPeriph_GPIOB | RCC_AHBPeriph_GPIOD | RCC_AHBPeriph_GPIOE, ENABLE);

	//                              SPI_SDA      SPI_CLK         LED       LCD_SPI_CS       BL         LCD_RST
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_22 | GPIO_Pin_23 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_16 | GPIO_Pin_17;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
	LCD_Initialize();

	//     配置4根同步信号线        DE=PB4, PCLK=PB5, HSYNC=PB6, VSYNC=PB7
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All & (~GPIO_Pin_17);
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOE, &GPIO_InitStructure);

	GPIO_PinAFConfig(GPIOB, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7,
	GPIO_AF_LTDC); //PB4~7复用为LTDC的同步信号线
	GPIO_PinAFConfig(GPIOE, GPIO_Pin_All, GPIO_AF_LTDC); //GPIOE所有的IO全部复用为LTDC的数据线

	GPIO_PinAFConfig(GPIOE,
	GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_16,
	GPIO_AF_GPIO); //把GPIOE中没用于液晶屏的IO设置为普通 IO

	//                              GPIO      GPIO         LED       LCD_SPI_CS       BL
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_16;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
	LCD_Light_ON();

}

void LCD_Init() //LCD初始化函数
{
	LCD_GpioInit(); //初始化液晶屏相关GPIO
	LCD_SetClockOfLTDC();
	LCD_SetTimingToLTDC();
	LCD_Light_ON(); //打开背光
}

void LCD_DrawPoint(u16 x0, u16 y0, int color) {
	u32 r = color & 0xff;
	u32 g = (color >> 8) & 0xff;
	u32 b = (color >> 16) & 0xff;

	color = (r << 16) | (g << 8) | b;

	LTDC_Buf[y0 + YSIZE_PHYS * x0] = color;
}

void LCD_FillRect(u16 x0, u16 y0, u16 w, u16 h, u32 color) {
	for (u16 j = 0; j < h; j++)
		for (u16 i = 0; i < w; i++)
			LCD_DrawPoint(x0 + i, y0 + j, color);
}

void LCD_Clear(u32 color) {
	for (u16 j = 0; j < YSIZE_PHYS; j++)
		for (u16 i = 0; i < XSIZE_PHYS; i++)
			LTDC_Buf[i + XSIZE_PHYS * j] = color;
}
