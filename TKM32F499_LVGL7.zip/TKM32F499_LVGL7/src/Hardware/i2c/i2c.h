/*
 * i2c.h
 *
 *  Created on: 2022年8月10日
 *      Author: legion
 */

#ifndef HARDWARE_I2C_I2C_H_
#define HARDWARE_I2C_I2C_H_

#include "HAL_conf.h"
void I2C_InitMasterMode(I2C_TypeDef *I2Cx);
void I2C_TXEmptyCheck(I2C_TypeDef *I2Cx);
void I2C_RXFullCheck(I2C_TypeDef *I2Cx);
void I2C_TXByte(I2C_TypeDef *I2Cx, unsigned short cmd, unsigned char temp);
unsigned char I2C_RXByte(I2C_TypeDef *I2Cx);

#endif /* HARDWARE_I2C_I2C_H_ */
