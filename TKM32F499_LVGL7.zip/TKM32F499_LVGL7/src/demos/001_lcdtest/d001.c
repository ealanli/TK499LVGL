/*
 * d001.c
 *
 *  Created on: 2022年8月14日
 *      Author: legion
 */
#include "HAL_conf.h"
#include "sys.h"

#include "Hardware/Hardware.h"

int demo001() {
	RemapVtorTable();
	SystemClk_HSEInit(RCC_PLLMul_20); //启动PLL时钟，12MHz*20=240MHz
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); //2：2，全局性函数，仅需设置一次

	LCD_Init();

	for (u32 i = 0;; i++) {
		LCD_Clear(i);
	};

	return 0;
}

