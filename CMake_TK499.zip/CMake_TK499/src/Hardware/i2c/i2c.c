#include "i2c.h"
#include "Hardware/touch/touch.h"

#pragma GCC push_options
#pragma GCC optimize("O0")

volatile unsigned char rx_flag = 0;
volatile unsigned char tx_flag = 0;
extern uint16_t I2C_DMA_DIR;
unsigned char tx_buffer0[16] = { 0x55, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0xa, 0xb, 0xc, 0xd, 0xe, 0xf };
unsigned char rx_buffer0[16];

volatile unsigned short txData_Number = 0;
volatile unsigned short txData_count = 0;
#define MXT224_ADDR		0x94		//地址为 0x4a<<1, 要移一位
#define FLASH_DEVICE_ADDR 0xa8
//#define FLASH_DEVICE_ADDR 0xa0

void I2C_InitMasterMode(I2C_TypeDef *I2Cx) {
	I2C_InitTypeDef I2C_InitStructure;
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);  //i2c1 clk enable

	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);

	GPIO_PinAFConfig(GPIOB, GPIO_Pin_0 | GPIO_Pin_2, GPIO_AF_I2C); //PB0、PB2复用为IIC

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD; // 复用开漏输出
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	//========== PB1 初始化为浮空输入
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	I2C_InitStructure.I2C_Mode = I2C_Mode_MASTER; //主模式
	I2C_InitStructure.I2C_OwnAddress = FT6206_ADDR;
	I2C_InitStructure.I2C_Speed = I2C_Speed_STANDARD;
	I2C_InitStructure.I2C_ClockSpeed = 400000;   //速度设置为400K
	I2C_Init(I2C1, &I2C_InitStructure);

	I2C_Send7bitAddress(I2C1, FT6206_ADDR, 0);
	I2C_Cmd(I2C1, ENABLE);
}

void I2C_TXEmptyCheck(I2C_TypeDef *I2Cx) {
	while (1) {
		if (I2C_GetFlagStatus(I2Cx, I2C_FLAG_TX_EMPTY)) {
			break;
		}
	}
}

void I2C_RXFullCheck(I2C_TypeDef *I2Cx) {
	int i = 0;
	while (1) {
		if (I2C_GetFlagStatus(I2Cx, I2C_FLAG_RX_FULL)) {
			break;
		}
		i++;
		if (i > 400)   //超时退出
			break;
	}
}

void I2C_TXByte(I2C_TypeDef *I2Cx, unsigned short cmd, unsigned char temp) {
	I2C_SendData(I2Cx, temp);
	I2C_TXEmptyCheck(I2Cx);
}

unsigned char I2C_RXByte(I2C_TypeDef *I2Cx) {
	I2C_RXFullCheck(I2Cx);
	return (unsigned char) I2C_ReceiveData(I2Cx);
}

#pragma GCC pop_options
