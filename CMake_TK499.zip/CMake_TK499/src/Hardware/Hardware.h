/*
 * Hardware.h
 *
 *  Created on: 2022年8月10日
 *      Author: legion
 */

#ifndef HARDWARE_HARDWARE_H_
#define HARDWARE_HARDWARE_H_

#include "lcd/lcd.h"
#include "i2c/i2c.h"
#include "touch/touch.h"



#endif /* HARDWARE_HARDWARE_H_ */
