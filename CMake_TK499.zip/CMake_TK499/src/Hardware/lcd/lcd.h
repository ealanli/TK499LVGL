/*
 * lcd.h
 *
 *  Created on: 2022年8月10日
 *      Author: legion
 */

#ifndef HARDWARE_LCD_LCD_H_
#define HARDWARE_LCD_LCD_H_

#include "HAL_conf.h"

// 24位色（1600万色）定义
#define White          0xFFFFFF
#define Black          0x000000
#define Blue           0xFF0000
#define Blue2          0xFF3F3F
#define Red            0x0000FF
#define Magenta        0xFF00FF
#define Green          0x00FF00
#define Cyan           0xFFFF00
#define Yellow         0x00FFFF

#define XSIZE_PHYS 800
#define YSIZE_PHYS 480
extern __attribute__ ((aligned(256))) u32 LTDC_Buf[XSIZE_PHYS * YSIZE_PHYS];

void LCD_Init();
void LCD_DrawPoint(u16 x0, u16 y0, int color);
void LCD_FillRect(u16 x0, u16 y0, u16 w, u16 h, u32 color);

#endif /* HARDWARE_LCD_LCD_H_ */
