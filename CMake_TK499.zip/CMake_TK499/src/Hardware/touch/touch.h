/*
 * touch.h
 *
 *  Created on: 2022年8月10日
 *      Author: legion
 */

#ifndef HARDWARE_TOUCH_TOUCH_H_
#define HARDWARE_TOUCH_TOUCH_H_

#include "HAL_conf.h"
#include "tk499.h"
#include "Hardware/i2c/i2c.h"

#define FT6206_ADDR		0x70		//地址为0x38要移一位

void Touch_Init();
int Touch_IsPressed();
void Touch_GetPos(u16 *x, u16 *y);

#endif /* HARDWARE_TOUCH_TOUCH_H_ */
