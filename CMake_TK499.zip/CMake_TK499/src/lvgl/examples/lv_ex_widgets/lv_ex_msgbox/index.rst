C
^

Simple Message box 
"""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_msgbox/lv_ex_msgbox_1
  :language: c



Modal 
""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_msgbox/lv_ex_msgbox_2
  :language: c


MicroPython
^^^^^^^^^^^

Simple Message box 
"""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_msgbox/lv_ex_msgbox_1
  :language: py


Modal 
""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_msgbox/lv_ex_msgbox_2
  :language: py
