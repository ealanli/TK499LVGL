C
^

Simple Text area
"""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_textarea/lv_ex_textarea_1
  :language: c
      
      
Text area with password field 
"""""""""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_textarea/lv_ex_textarea_2
  :language: c
      
Text auto-formatting
"""""""""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_textarea/lv_ex_textarea_3
  :language: c

MicroPython
^^^^^^^^^^^

Simple Text area
"""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_textarea/lv_ex_textarea_1
  :language: py
      
      
Text area with password field 
"""""""""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_textarea/lv_ex_textarea_2
  :language: py
      
Text auto-formatting
"""""""""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_textarea/lv_ex_textarea_3
  :language: py
