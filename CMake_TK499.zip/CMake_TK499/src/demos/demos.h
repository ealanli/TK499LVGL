/*
 * demos.h
 *
 *  Created on: 2022年8月14日
 *      Author: legion
 */

#ifndef DEMOS_DEMOS_H_
#define DEMOS_DEMOS_H_

int demo001();



#endif /* DEMOS_DEMOS_H_ */
